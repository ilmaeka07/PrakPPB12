package com.example.crudroom

class NoteAdapter {
}